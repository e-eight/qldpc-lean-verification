"""Exact sector orientation, completeness, provenance and rounding controls."""

import copy
import gzip
import json
from fractions import Fraction

import pytest
from distance566_sector import (
    build_problem,
    choose_weights,
    exact_arithmetic,
    gzip_bytes,
    pack_residue,
)
from distance566_sector_verify import check_case, validate_record


def repetition_fixture(bounded="Z", good_rank=15):
    # Eighteen disjoint seven-bit repetition sectors: k=18, one distance seven.
    paired_rows = [[7 * i, 7 * i + j] for i in range(18) for j in range(1, 7)]
    singles = [[7 * i] for i in range(18)]
    blocks = [list(range(7 * i, 7 * i + 7)) for i in range(18)]
    side = "X" if bounded == "Z" else "Z"
    code = {"n": 126, "checks": {side: paired_rows, bounded: []}}
    coordinates = {side: singles, bounded: blocks}
    families = []
    for i in range(18):
        reps = [
            {
                "support": [7 * i + j],
                "rows": [] if j == 0 else [6 * i + j - 1],
                "weight": 1 if i < good_rank or j < 6 else 0,
            }
            for j in range(7)
        ]
        total = 7 if i < good_rank else 6
        families.append(
            {
                "n": 126,
                "detector_side": side,
                "bounded_side": bounded,
                "class": 1 << i,
                "base_support": singles[i],
                "representatives": reps,
                "arithmetic": {"totalWeight": total, "cap": 1, "bound": total},
            }
        )
    source = {
        "detector_side": side,
        "bounded_side": bounded,
        "families": families,
        "coverage": {
            "detector_side": side,
            "bounded_side": bounded,
            "classes": [1 << i for i in range(18)],
            "detectors": singles,
            "paired_witnesses": [{"support": blocks[i], "old_basis_rows": [i]} for i in range(18)],
            "bound": 6,
        },
    }
    record = build_problem(code, coordinates, source, bounded, None if bounded == "Z" else 32)
    record["residues"] = [pack_residue(record, case, source, 0)[0] for case in record["residues"]]
    record["all_requested_passed"] = True
    return code, coordinates, source, record


def test_seven_residues_cover_nonzero_sums_and_pair_physically():
    code, coordinates, source, record = repetition_fixture()
    report = validate_record(code, coordinates, record, source)
    assert report["cases_checked"] == 7
    assert report["good_rank"] == 15 and report["annihilator_dimension"] == 3
    assert report["complete_residue_coverage"] and report["all_requested_passed"]
    assert [r["suffix_pattern"] for r in record["residues"]] == list(range(1, 8))
    assert len(record["pool"]) == 21
    assert all(r["quotient_class"] for r in record["pool"])


@pytest.mark.parametrize(
    "fault",
    [
        "sector",
        "dependent",
        "good_span",
        "missing_sum",
        "reference",
        "row_index",
        "row_mask",
        "physical_mask",
        "weight_bool",
        "weight_float",
        "cap",
        "quotient",
        "annihilator",
    ],
)
def test_reject_malformed_sector_certificate(fault):
    code, coordinates, source, original = repetition_fixture()
    record = copy.deepcopy(original)
    if fault == "sector":
        record["bounded_side"] = record["detector_side"]
    elif fault == "dependent":
        record["selected_basis"]["classes"][1] = record["selected_basis"]["classes"][0]
    elif fault == "good_span":
        record["good_families"][0]["class"] = 1 << 17
    elif fault == "missing_sum":
        record["residues"] = [r for r in record["residues"] if r["suffix_pattern"] != 3]
    elif fault == "reference":
        record["residues"][0]["reference_support"].pop()
    elif fault == "row_index":
        record["pool"][0]["provenances"][0]["rows"] = [108]
    elif fault == "row_mask":
        record["pool"][0]["provenances"][0]["row_mask"] = 1
    elif fault == "physical_mask":
        record["pool"][0]["mask"] ^= 1
    elif fault == "weight_bool":
        record["residues"][0]["weights"][0][1] = True
    elif fault == "weight_float":
        record["residues"][0]["weights"][0][1] = 1.0
    elif fault == "cap":
        record["residues"][0]["arithmetic"]["cap"] = 2
    elif fault == "quotient":
        record["pool"][0]["quotient_class"] = 0
    elif fault == "annihilator":
        record["annihilator"]["canonical_basis"][1] = record["annihilator"]["canonical_basis"][0]
    with pytest.raises(ValueError):
        validate_record(code, coordinates, record, source)


def test_direct_pairing_check_does_not_trust_class_tag():
    code, coordinates, _, record = repetition_fixture()
    case = record["residues"][0]
    index = case["weights"][0][0]
    # The cached canonical/quotient tags still report compatibility. The actual
    # physical vector now lives in a different repetition block and pairs zero.
    record["pool"][index]["support"] = [7 * 16]
    with pytest.raises(ValueError, match="Direct physical pairing"):
        check_case(code, coordinates, record, case)


def test_strict_equality_is_not_seven_and_partial_profile_is_retained():
    code, coordinates, source, record = repetition_fixture()
    case = record["residues"][0]
    case["weights"].pop()
    vectors = [record["pool"][i]["mask"] for i, _ in case["weights"]]
    case["arithmetic"] = exact_arithmetic(vectors, [w for _, w in case["weights"]], 126)
    assert case["arithmetic"]["totalWeight"] == 6 * case["arithmetic"]["cap"]
    with pytest.raises(ValueError, match="Strict inequality"):
        check_case(code, coordinates, record, case, require_seven=True)
    with pytest.raises(ValueError, match="aggregate threshold"):
        validate_record(code, coordinates, record, source)
    record["all_requested_passed"] = False
    report = validate_record(code, coordinates, record, source)
    assert not report["all_requested_passed"]
    assert report["results"][0]["bound"] == 6


def test_pool_must_preserve_all_original_provenances():
    code, coordinates, source, record = repetition_fixture()
    record["pool"][0]["provenances"][0]["source_rep_index"] = 1
    with pytest.raises(ValueError, match="lost original"):
        validate_record(code, coordinates, record, source)


def test_x_pilot_is_partial_and_capped_at_thirty_two():
    code, coordinates, source, record = repetition_fixture("X", 7)
    report = validate_record(code, coordinates, record, source)
    assert report["cases_checked"] == 32 and not report["complete_residue_coverage"]
    assert record["residue_scope"]["total_nonzero"] == 2047
    with pytest.raises(ValueError, match="not authorized"):
        build_problem(code, coordinates, source, "X", 2047)


def test_export_bytes_are_stable_and_timestamp_free():
    record = repetition_fixture()[3]
    first = gzip_bytes(record)
    assert first == gzip_bytes(record)
    assert gzip_bytes({"a": 1, "b": 2}) == gzip_bytes({"b": 2, "a": 1})
    assert json.loads(gzip.decompress(first)) == record
    assert first[4:8] == bytes(4)


def test_optional_lp_proposal_is_exactly_rechecked():
    pytest.importorskip("scipy")
    vectors = [1, 1, 1, 2, 4]
    weights, arithmetic, dual, details = choose_weights(vectors, 3, [("uniform", [1] * 5)], 1)
    assert details["solver"]["success"]
    assert Fraction(arithmetic["totalWeight"], arithmetic["cap"]) == 3
    assert arithmetic == exact_arithmetic(vectors, weights, 3)
    assert all(
        sum(dual["qubit_weights"][q] for q in range(3) if v >> q & 1) >= dual["denominator"]
        for v in vectors
    )
